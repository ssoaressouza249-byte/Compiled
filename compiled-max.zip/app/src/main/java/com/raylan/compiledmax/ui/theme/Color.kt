package com.raylan.compiledmax.ui.theme

import androidx.compose.ui.graphics.Color

val GamerBg = Color(0xFF0A0B10)
val GamerCard = Color(0xFF141722)
val GamerCardElevated = Color(0xFF1B1F2E)
val GamerBorder = Color(0xFF262C40)
val GamerTerminalBg = Color(0xFF06070B)

val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDim = Color(0xFF00A8B5)
val NeonGreen = Color(0xFF00E676)
val NeonGreenDim = Color(0xFF00A854)
val NeonAmber = Color(0xFFFFB300)
val CrimsonError = Color(0xFFFF2A55)
val TamperScreenRed = Color(0xFFB71C1C)
val TamperScreenDarkRed = Color(0xFF6A0000)

val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFF8E97B2)
val TextMuted = Color(0xFF5C647D)
