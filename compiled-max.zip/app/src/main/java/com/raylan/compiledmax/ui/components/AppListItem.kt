package com.raylan.compiledmax.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.compiledmax.R
import com.raylan.compiledmax.model.AppCompileState
import com.raylan.compiledmax.model.InstalledApp
import com.raylan.compiledmax.ui.theme.CrimsonError
import com.raylan.compiledmax.ui.theme.GamerBg
import com.raylan.compiledmax.ui.theme.GamerBorder
import com.raylan.compiledmax.ui.theme.GamerCard
import com.raylan.compiledmax.ui.theme.GamerCardElevated
import com.raylan.compiledmax.ui.theme.NeonCyan
import com.raylan.compiledmax.ui.theme.NeonGreen
import com.raylan.compiledmax.ui.theme.TextMuted
import com.raylan.compiledmax.ui.theme.TextPrimary
import com.raylan.compiledmax.ui.theme.TextSecondary

@Composable
fun AppListItem(
    app: InstalledApp,
    isSelected: Boolean,
    enabled: Boolean,
    loadIcon: suspend (String) -> ImageBitmap?,
    onToggleSelection: () -> Unit,
    modifier: Modifier = Modifier
) {
    val iconBitmap by produceState<ImageBitmap?>(initialValue = null, key1 = app.packageName) {
        value = loadIcon(app.packageName)
    }

    val borderColor = when {
        app.compileState == AppCompileState.COMPILING -> NeonCyan
        isSelected -> NeonCyan.copy(alpha = 0.65f)
        else -> GamerBorder
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onToggleSelection)
            .testTag("app_item_${app.packageName}"),
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) GamerCardElevated else GamerCard
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(GamerBg)
                    .border(1.dp, GamerBorder, RoundedCornerShape(11.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (iconBitmap != null) {
                    Image(
                        bitmap = iconBitmap!!,
                        contentDescription = app.name,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(9.dp)),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.Android,
                        contentDescription = app.name,
                        tint = TextMuted,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = app.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    CategoryBadge(app = app)
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = app.packageName,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "${app.formattedSize} • v${app.versionName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    CompileStatusChip(app = app)
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            if (app.compileState == AppCompileState.COMPILING) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.5.dp,
                    color = NeonCyan
                )
            } else {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { if (enabled) onToggleSelection() },
                    enabled = enabled,
                    colors = CheckboxDefaults.colors(
                        checkedColor = NeonCyan,
                        uncheckedColor = TextSecondary,
                        checkmarkColor = GamerBg
                    ),
                    modifier = Modifier.testTag("checkbox_${app.packageName}")
                )
            }
        }
    }
}

@Composable
private fun CategoryBadge(app: InstalledApp) {
    val (label, color) = when {
        app.isGame -> stringResource(R.string.badge_game) to NeonGreen
        !app.isSystemApp -> stringResource(R.string.badge_user) to NeonCyan
        else -> stringResource(R.string.badge_system) to TextMuted
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.14f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
private fun CompileStatusChip(app: InstalledApp) {
    val statusText = app.lastStatusMessage ?: return
    val color = when (app.compileState) {
        AppCompileState.SUCCESS -> NeonGreen
        AppCompileState.ERROR -> CrimsonError
        AppCompileState.COMPILING -> NeonCyan
        AppCompileState.IDLE -> Color.Transparent
    }
    if (color == Color.Transparent) return

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.14f))
            .padding(horizontal = 6.dp, vertical = 1.dp)
    ) {
        Text(
            text = statusText,
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            color = color,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
