package com.raylan.compiledmax.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val GamerDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = GamerBg,
    primaryContainer = NeonCyanDim.copy(alpha = 0.18f),
    onPrimaryContainer = NeonCyan,
    secondary = NeonGreen,
    onSecondary = GamerBg,
    secondaryContainer = NeonGreenDim.copy(alpha = 0.18f),
    onSecondaryContainer = NeonGreen,
    tertiary = NeonAmber,
    onTertiary = GamerBg,
    background = GamerBg,
    onBackground = TextPrimary,
    surface = GamerCard,
    onSurface = TextPrimary,
    surfaceVariant = GamerCardElevated,
    onSurfaceVariant = TextSecondary,
    outline = GamerBorder,
    outlineVariant = GamerBorder.copy(alpha = 0.6f),
    error = CrimsonError,
    onError = TextPrimary
)

private val CompiledMaxShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp)
)

@Composable
fun CompiledMaxTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GamerDarkColorScheme,
        typography = CompiledMaxTypography,
        shapes = CompiledMaxShapes,
        content = content
    )
}
