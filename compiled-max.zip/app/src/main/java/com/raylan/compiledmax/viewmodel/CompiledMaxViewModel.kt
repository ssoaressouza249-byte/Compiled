package com.raylan.compiledmax.viewmodel

import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.raylan.compiledmax.data.AppRepository
import com.raylan.compiledmax.model.AppCompileState
import com.raylan.compiledmax.model.AppFilter
import com.raylan.compiledmax.model.CompilationProfile
import com.raylan.compiledmax.model.CompilationProgress
import com.raylan.compiledmax.model.InstalledApp
import com.raylan.compiledmax.model.LogType
import com.raylan.compiledmax.model.ShizukuStatus
import com.raylan.compiledmax.model.TerminalLogLine
import com.raylan.compiledmax.shizuku.ShizukuHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

class CompiledMaxViewModel(
    private val shizukuHelper: ShizukuHelper,
    private val appRepository: AppRepository
) : ViewModel() {

    val shizukuStatus: StateFlow<ShizukuStatus> = shizukuHelper.status
    val shizukuInfo: StateFlow<String> = shizukuHelper.shizukuInfo

    private val _allApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    private val _isLoadingApps = MutableStateFlow(true)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow(AppFilter.USER)
    val selectedFilter: StateFlow<AppFilter> = _selectedFilter.asStateFlow()

    private val _selectedPackages = MutableStateFlow<Set<String>>(emptySet())
    val selectedPackages: StateFlow<Set<String>> = _selectedPackages.asStateFlow()

    private val _selectedProfile = MutableStateFlow(CompilationProfile.SPEED)
    val selectedProfile: StateFlow<CompilationProfile> = _selectedProfile.asStateFlow()

    private val _compilationProgress = MutableStateFlow(CompilationProgress())
    val compilationProgress: StateFlow<CompilationProgress> = _compilationProgress.asStateFlow()

    private val _terminalLogs = MutableStateFlow<List<TerminalLogLine>>(emptyList())
    val terminalLogs: StateFlow<List<TerminalLogLine>> = _terminalLogs.asStateFlow()

    private val _isTerminalOpen = MutableStateFlow(false)
    val isTerminalOpen: StateFlow<Boolean> = _isTerminalOpen.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    val filteredApps: StateFlow<List<InstalledApp>> = combine(
        _allApps,
        _searchQuery,
        _selectedFilter
    ) { apps, query, filter ->
        val trimmedQuery = query.trim().lowercase(Locale.getDefault())
        apps.filter { app ->
            val matchesFilter = when (filter) {
                AppFilter.ALL -> true
                AppFilter.USER -> !app.isSystemApp
                AppFilter.GAMES -> app.isGame
            }
            val matchesSearch = if (trimmedQuery.isEmpty()) {
                true
            } else {
                app.name.lowercase(Locale.getDefault()).contains(trimmedQuery) ||
                    app.packageName.lowercase(Locale.getDefault()).contains(trimmedQuery)
            }
            matchesFilter && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    private val logIdCounter = AtomicLong(0L)
    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private var compileJob: Job? = null

    init {
        loadApps()
    }

    fun loadApps() {
        viewModelScope.launch {
            _isLoadingApps.value = true
            val loaded = runCatching { appRepository.loadInstalledApps() }
                .getOrElse {
                    _snackbarMessage.value = "Falha ao listar aplicativos instalados."
                    emptyList()
                }
            _allApps.value = loaded
            _isLoadingApps.value = false
        }
    }

    suspend fun getAppIcon(packageName: String): ImageBitmap? {
        return appRepository.getAppIcon(packageName)
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun onFilterChange(filter: AppFilter) {
        _selectedFilter.value = filter
    }

    fun onProfileSelect(profile: CompilationProfile) {
        if (!_compilationProgress.value.isRunning) {
            _selectedProfile.value = profile
        }
    }

    fun togglePackageSelection(packageName: String) {
        if (_compilationProgress.value.isRunning) return
        _selectedPackages.update { current ->
            if (packageName in current) current - packageName else current + packageName
        }
    }

    fun selectAllVisible() {
        if (_compilationProgress.value.isRunning) return
        val visiblePackages = filteredApps.value.map { it.packageName }
        _selectedPackages.update { it + visiblePackages }
    }

    fun deselectAll() {
        if (_compilationProgress.value.isRunning) return
        _selectedPackages.value = emptySet()
    }

    fun onConnectOrAuthorizeShizuku() {
        val message = shizukuHelper.connectOrRequestPermission()
        if (message != null) {
            _snackbarMessage.value = message
        }
    }

    fun openTerminal() {
        _isTerminalOpen.value = true
    }

    fun closeTerminal() {
        _isTerminalOpen.value = false
    }

    fun clearTerminal() {
        if (!_compilationProgress.value.isRunning) {
            _terminalLogs.value = emptyList()
        }
    }

    fun consumeSnackbar() {
        _snackbarMessage.value = null
    }

    fun startCompilation() {
        if (_compilationProgress.value.isRunning) return

        val status = shizukuHelper.refreshStatus()
        if (status != ShizukuStatus.CONNECTED) {
            val feedback = shizukuHelper.connectOrRequestPermission()
            _snackbarMessage.value = feedback
                ?: "Autorize o Shizuku antes de iniciar a compilação."
            return
        }

        val selectedSet = _selectedPackages.value
        val queue = _allApps.value.filter { it.packageName in selectedSet }
        if (queue.isEmpty()) {
            _snackbarMessage.value = "Selecione ao menos um aplicativo."
            return
        }

        val profile = _selectedProfile.value
        _isTerminalOpen.value = true

        compileJob = viewModelScope.launch {
            var successCount = 0
            var errorCount = 0

            appendLog(
                "Iniciando fila ART (${profile.badgeLabel}) • ${queue.size} pacote(s)",
                LogType.INFO
            )

            try {
                queue.forEachIndexed { index, app ->
                    _compilationProgress.value = CompilationProgress(
                        isRunning = true,
                        currentIndex = index + 1,
                        totalCount = queue.size,
                        currentAppName = app.name,
                        currentPackageName = app.packageName
                    )

                    updateAppState(app.packageName, AppCompileState.COMPILING, "Compilando...")

                    val command = profile.buildCommand(app.packageName)
                    appendLog("$ $command", LogType.COMMAND)

                    var receivedAnyLine = false
                    val result = shizukuHelper.executeCommand(command) { line, isErr ->
                        receivedAnyLine = true
                        val type = when {
                            isErr -> LogType.ERROR
                            line.contains("Success", ignoreCase = true) -> LogType.SUCCESS
                            else -> LogType.OUTPUT
                        }
                        appendLog("  $line", type)
                    }

                    if (!receivedAnyLine && result.combinedOutput.isNotBlank()) {
                        val type = if (result.isSuccess) LogType.OUTPUT else LogType.ERROR
                        appendLog("  ${result.combinedOutput}", type)
                    } else if (!receivedAnyLine && result.isSuccess) {
                        appendLog("  Success", LogType.SUCCESS)
                    }

                    if (result.isSuccess) {
                        successCount++
                        val shortMsg = result.stdout.lines().firstOrNull { it.isNotBlank() }
                            ?.take(24) ?: "Success"
                        updateAppState(app.packageName, AppCompileState.SUCCESS, shortMsg)
                    } else {
                        errorCount++
                        if (result.stderr.isBlank() && !receivedAnyLine) {
                            appendLog("  Falha (código ${result.exitCode})", LogType.ERROR)
                        }
                        updateAppState(
                            app.packageName,
                            AppCompileState.ERROR,
                            "Erro (${result.exitCode})"
                        )
                    }
                }

                appendLog(
                    "Concluído: $successCount sucesso(s), $errorCount falha(s).",
                    if (errorCount == 0) LogType.SUCCESS else LogType.INFO
                )
            } catch (cancel: CancellationException) {
                appendLog("Compilação interrompida pelo usuário.", LogType.ERROR)
                throw cancel
            } finally {
                _compilationProgress.value = CompilationProgress(isRunning = false)
                resetCompilingStates()
            }
        }
    }

    fun cancelCompilation() {
        compileJob?.cancel()
        compileJob = null
    }

    private fun updateAppState(packageName: String, state: AppCompileState, message: String) {
        _allApps.update { list ->
            list.map { item ->
                if (item.packageName == packageName) {
                    item.copy(compileState = state, lastStatusMessage = message)
                } else {
                    item
                }
            }
        }
    }

    private fun resetCompilingStates() {
        _allApps.update { list ->
            list.map { item ->
                if (item.compileState == AppCompileState.COMPILING) {
                    item.copy(compileState = AppCompileState.IDLE, lastStatusMessage = null)
                } else {
                    item
                }
            }
        }
    }

    private fun appendLog(text: String, type: LogType) {
        val timestamp = synchronized(timeFormatter) { timeFormatter.format(Date()) }
        val entry = TerminalLogLine(
            id = logIdCounter.incrementAndGet(),
            timestamp = timestamp,
            text = text,
            type = type
        )
        _terminalLogs.update { current ->
            (current + entry).takeLast(400)
        }
    }

    class Factory(
        private val shizukuHelper: ShizukuHelper,
        private val appRepository: AppRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return CompiledMaxViewModel(shizukuHelper, appRepository) as T
        }
    }
}
