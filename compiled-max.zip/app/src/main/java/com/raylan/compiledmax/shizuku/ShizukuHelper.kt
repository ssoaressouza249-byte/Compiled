package com.raylan.compiledmax.shizuku

import android.content.Context
import android.content.pm.PackageManager
import com.raylan.compiledmax.model.ShizukuStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuProvider
import rikka.shizuku.ShizukuRemoteProcess
import java.io.BufferedReader
import java.io.InputStreamReader

data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val isSuccess: Boolean
) {
    val combinedOutput: String
        get() = buildString {
            if (stdout.isNotBlank()) append(stdout.trim())
            if (stderr.isNotBlank()) {
                if (isNotEmpty()) append('\n')
                append(stderr.trim())
            }
        }
}

class ShizukuHelper(private val context: Context) {

    companion object {
        const val REQUEST_CODE_SHIZUKU_PERMISSION = 1001
        private const val SHIZUKU_MANAGER_PACKAGE = "moe.shizuku.privileged.api"
    }

    private val _status = MutableStateFlow(ShizukuStatus.NOT_STARTED)
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    private val _shizukuInfo = MutableStateFlow("Shizuku API 13.1.5")
    val shizukuInfo: StateFlow<String> = _shizukuInfo.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _status.value = ShizukuStatus.NOT_STARTED
        _shizukuInfo.value = "Binder desconectado"
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_CODE_SHIZUKU_PERMISSION) {
                refreshStatus()
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    _shizukuInfo.value = "Permissão recusada pelo usuário"
                }
            }
        }

    fun registerLifecycleListeners() {
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        }
        runCatching {
            Shizuku.addBinderDeadListener(binderDeadListener)
        }
        runCatching {
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
        }
        refreshStatus()
    }

    fun unregisterLifecycleListeners() {
        runCatching {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
        }
        runCatching {
            Shizuku.removeBinderDeadListener(binderDeadListener)
        }
        runCatching {
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        }
    }

    fun refreshStatus(): ShizukuStatus {
        val currentStatus = runCatching {
            val isBinderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
            if (!isBinderAlive) {
                _shizukuInfo.value = "Serviço Shizuku inativo"
                ShizukuStatus.NOT_STARTED
            } else if (hasShizukuPermission()) {
                val uid = runCatching { Shizuku.getUid() }.getOrNull()
                val version = runCatching { Shizuku.getVersion() }.getOrNull()
                val privilegeLabel = when (uid) {
                    0 -> "UID 0 (Root)"
                    2000 -> "UID 2000 (ADB Shell)"
                    else -> uid?.let { "UID $it" } ?: "Ativo"
                }
                val versionLabel = version?.let { "API v$it • " } ?: ""
                _shizukuInfo.value = "$versionLabel$privilegeLabel"
                ShizukuStatus.CONNECTED
            } else {
                _shizukuInfo.value = "Toque para autorizar o acesso"
                ShizukuStatus.AWAITING_PERMISSION
            }
        }.getOrElse {
            _shizukuInfo.value = "Erro ao consultar Shizuku"
            ShizukuStatus.NOT_STARTED
        }
        _status.value = currentStatus
        return currentStatus
    }

    private fun hasShizukuPermission(): Boolean {
        return runCatching {
            if (Shizuku.isPreV11()) {
                context.checkSelfPermission(ShizukuProvider.PERMISSION) == PackageManager.PERMISSION_GRANTED
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        }.getOrDefault(false)
    }

    fun connectOrRequestPermission(): String? {
        val current = refreshStatus()
        return when (current) {
            ShizukuStatus.CONNECTED -> null
            ShizukuStatus.AWAITING_PERMISSION -> {
                val requested = runCatching {
                    if (Shizuku.isPreV11()) {
                        false
                    } else {
                        Shizuku.requestPermission(REQUEST_CODE_SHIZUKU_PERMISSION)
                        true
                    }
                }.getOrDefault(false)
                if (!requested) {
                    "Não foi possível abrir o diálogo de permissão do Shizuku."
                } else {
                    null
                }
            }
            ShizukuStatus.NOT_STARTED -> {
                val opened = runCatching {
                    val launchIntent = context.packageManager
                        .getLaunchIntentForPackage(SHIZUKU_MANAGER_PACKAGE)
                    if (launchIntent != null) {
                        launchIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        true
                    } else {
                        false
                    }
                }.getOrDefault(false)
                if (opened) {
                    "Abrindo Shizuku. Inicie o serviço e volte para o Compiled Max."
                } else {
                    "Shizuku não está instalado ou ativo. Instale e inicie o serviço Shizuku."
                }
            }
        }
    }

    suspend fun executeCommand(
        command: String,
        onLineOutput: ((String, Boolean) -> Unit)? = null
    ): ShellResult = withContext(Dispatchers.IO) {
        val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!binderAlive || !hasShizukuPermission()) {
            refreshStatus()
            return@withContext ShellResult(
                exitCode = -1,
                stdout = "",
                stderr = "Shizuku não conectado ou sem permissão.",
                isSuccess = false
            )
        }

        val processResult = runCatching {
            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply {
                isAccessible = true
            }
            newProcessMethod.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as ShizukuRemoteProcess
        }

        val process = processResult.getOrElse { error ->
            return@withContext ShellResult(
                exitCode = -1,
                stdout = "",
                stderr = error.localizedMessage ?: "Falha ao iniciar processo via Shizuku.",
                isSuccess = false
            )
        }

        try {
            coroutineScope {
                val stdoutDeferred = async(Dispatchers.IO) {
                    val sb = StringBuilder()
                    runCatching {
                        BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                            var line: String?
                            while (reader.readLine().also { line = it } != null) {
                                val text = line ?: continue
                                sb.appendLine(text)
                                onLineOutput?.invoke(text, false)
                            }
                        }
                    }
                    sb.toString()
                }

                val stderrDeferred = async(Dispatchers.IO) {
                    val sb = StringBuilder()
                    runCatching {
                        BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                            var line: String?
                            while (reader.readLine().also { line = it } != null) {
                                val text = line ?: continue
                                sb.appendLine(text)
                                onLineOutput?.invoke(text, true)
                            }
                        }
                    }
                    sb.toString()
                }

                val stdout = stdoutDeferred.await()
                val stderr = stderrDeferred.await()
                val exitCode = runCatching { process.waitFor() }.getOrDefault(-1)

                ShellResult(
                    exitCode = exitCode,
                    stdout = stdout.trim(),
                    stderr = stderr.trim(),
                    isSuccess = exitCode == 0
                )
            }
        } catch (t: Throwable) {
            ShellResult(
                exitCode = -1,
                stdout = "",
                stderr = t.localizedMessage ?: "Erro durante a execução do comando.",
                isSuccess = false
            )
        } finally {
            runCatching { process.destroy() }
        }
    }
}
