package com.raylan.compiledmax.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.raylan.compiledmax.R
import com.raylan.compiledmax.model.CompilationProfile
import com.raylan.compiledmax.ui.theme.GamerBorder
import com.raylan.compiledmax.ui.theme.GamerCard
import com.raylan.compiledmax.ui.theme.GamerTerminalBg
import com.raylan.compiledmax.ui.theme.NeonAmber
import com.raylan.compiledmax.ui.theme.NeonCyan
import com.raylan.compiledmax.ui.theme.NeonGreen
import com.raylan.compiledmax.ui.theme.TextPrimary
import com.raylan.compiledmax.ui.theme.TextSecondary

@Composable
fun ProfileSelectorSection(
    selectedProfile: CompilationProfile,
    enabled: Boolean,
    onSelectProfile: (CompilationProfile) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = stringResource(R.string.section_profile_title),
            style = MaterialTheme.typography.titleSmall,
            color = NeonCyan,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(10.dp))

        val profiles = CompilationProfile.entries
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ProfileCard(
                    profile = profiles[0],
                    isSelected = selectedProfile == profiles[0],
                    enabled = enabled,
                    onClick = { onSelectProfile(profiles[0]) },
                    modifier = Modifier.weight(1f)
                )
                ProfileCard(
                    profile = profiles[1],
                    isSelected = selectedProfile == profiles[1],
                    enabled = enabled,
                    onClick = { onSelectProfile(profiles[1]) },
                    modifier = Modifier.weight(1f)
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ProfileCard(
                    profile = profiles[2],
                    isSelected = selectedProfile == profiles[2],
                    enabled = enabled,
                    onClick = { onSelectProfile(profiles[2]) },
                    modifier = Modifier.weight(1f)
                )
                ProfileCard(
                    profile = profiles[3],
                    isSelected = selectedProfile == profiles[3],
                    enabled = enabled,
                    onClick = { onSelectProfile(profiles[3]) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(GamerTerminalBg)
                .border(1.dp, GamerBorder, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(
                text = "$ ${selectedProfile.commandTemplate}",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = NeonGreen,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ProfileCard(
    profile: CompilationProfile,
    isSelected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = when (profile) {
        CompilationProfile.SPEED -> NeonCyan
        CompilationProfile.EVERYTHING -> NeonGreen
        CompilationProfile.SPACE -> Color(0xFF7C4DFF)
        CompilationProfile.RESET -> NeonAmber
    }

    val borderColor by animateColorAsState(
        targetValue = if (isSelected) accent else GamerBorder,
        label = "profile_border"
    )
    val bgColor by animateColorAsState(
        targetValue = if (isSelected) accent.copy(alpha = 0.13f) else GamerCard,
        label = "profile_bg"
    )

    val icon = when (profile) {
        CompilationProfile.SPEED -> Icons.Filled.Bolt
        CompilationProfile.EVERYTHING -> Icons.Filled.RocketLaunch
        CompilationProfile.SPACE -> Icons.Filled.Savings
        CompilationProfile.RESET -> Icons.Filled.CleaningServices
    }

    Surface(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(14.dp))
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .testTag("profile_card_${profile.id}"),
        shape = RoundedCornerShape(14.dp),
        color = bgColor
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) accent else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = profile.badgeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) accent else TextSecondary
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(profile.titleRes),
                style = MaterialTheme.typography.titleSmall,
                color = if (isSelected) TextPrimary else TextPrimary.copy(alpha = 0.88f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = stringResource(profile.descriptionRes),
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
