package com.raylan.compiledmax.model

import androidx.annotation.StringRes
import com.raylan.compiledmax.R

enum class ShizukuStatus {
    NOT_STARTED,
    AWAITING_PERMISSION,
    CONNECTED
}

enum class CompilationProfile(
    val id: String,
    @StringRes val titleRes: Int,
    @StringRes val descriptionRes: Int,
    val commandTemplate: String,
    val badgeLabel: String
) {
    SPEED(
        id = "speed",
        titleRes = R.string.profile_speed_title,
        descriptionRes = R.string.profile_speed_desc,
        commandTemplate = "cmd package compile -m speed -f <pacote>",
        badgeLabel = "SPEED"
    ),
    EVERYTHING(
        id = "everything",
        titleRes = R.string.profile_everything_title,
        descriptionRes = R.string.profile_everything_desc,
        commandTemplate = "cmd package compile -m everything -f <pacote>",
        badgeLabel = "EXTREME"
    ),
    SPACE(
        id = "space",
        titleRes = R.string.profile_space_title,
        descriptionRes = R.string.profile_space_desc,
        commandTemplate = "cmd package compile -m space-profile -f <pacote>",
        badgeLabel = "SPACE"
    ),
    RESET(
        id = "reset",
        titleRes = R.string.profile_reset_title,
        descriptionRes = R.string.profile_reset_desc,
        commandTemplate = "cmd package compile --reset <pacote>",
        badgeLabel = "RESET"
    );

    fun buildCommand(packageName: String): String {
        val safePackage = packageName.filter { it.isLetterOrDigit() || it == '.' || it == '_' || it == '-' }
        return when (this) {
            SPEED -> "cmd package compile -m speed -f $safePackage"
            EVERYTHING -> "cmd package compile -m everything -f $safePackage"
            SPACE -> "cmd package compile -m space-profile -f $safePackage"
            RESET -> "cmd package compile --reset $safePackage"
        }
    }
}

enum class AppFilter(@StringRes val labelRes: Int) {
    ALL(R.string.filter_all),
    USER(R.string.filter_user),
    GAMES(R.string.filter_games)
}

enum class AppCompileState {
    IDLE,
    COMPILING,
    SUCCESS,
    ERROR
}

data class InstalledApp(
    val name: String,
    val packageName: String,
    val sizeBytes: Long,
    val formattedSize: String,
    val isSystemApp: Boolean,
    val isGame: Boolean,
    val versionName: String,
    val compileState: AppCompileState = AppCompileState.IDLE,
    val lastStatusMessage: String? = null
)

enum class LogType {
    INFO,
    COMMAND,
    OUTPUT,
    SUCCESS,
    ERROR
}

data class TerminalLogLine(
    val id: Long,
    val timestamp: String,
    val text: String,
    val type: LogType
)

data class CompilationProgress(
    val isRunning: Boolean = false,
    val currentIndex: Int = 0,
    val totalCount: Int = 0,
    val currentAppName: String = "",
    val currentPackageName: String = ""
) {
    val fraction: Float
        get() = if (totalCount <= 0) 0f else (currentIndex.toFloat() / totalCount.toFloat()).coerceIn(0f, 1f)
}
