package com.raylan.compiledmax.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.raylan.compiledmax.model.InstalledApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class AppRepository(private val context: Context) {

    private val iconCache = ConcurrentHashMap<String, ImageBitmap>()

    suspend fun loadInstalledApps(): List<InstalledApp> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val packages = runCatching {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(PackageManager.GET_META_DATA)
        }.getOrElse {
            runCatching { pm.getInstalledPackages(0) }.getOrDefault(emptyList())
        }

        packages.mapNotNull { pkgInfo ->
            val appInfo = pkgInfo.applicationInfo ?: return@mapNotNull null
            val packageName = pkgInfo.packageName ?: return@mapNotNull null

            val appName = runCatching {
                pm.getApplicationLabel(appInfo).toString().ifBlank { packageName }
            }.getOrDefault(packageName)

            val isSystem = runCatching {
                val systemFlag = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val updatedSystemFlag = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                systemFlag && !updatedSystemFlag
            }.getOrDefault(false)

            val isGame = runCatching {
                @Suppress("DEPRECATION")
                val legacyGameFlag = (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                appInfo.category == ApplicationInfo.CATEGORY_GAME || legacyGameFlag
            }.getOrDefault(false)

            val sizeBytes = runCatching {
                var total = 0L
                appInfo.sourceDir?.let { path ->
                    val baseFile = File(path)
                    if (baseFile.exists()) total += baseFile.length()
                }
                appInfo.splitSourceDirs?.forEach { splitPath ->
                    val splitFile = File(splitPath)
                    if (splitFile.exists()) total += splitFile.length()
                }
                total
            }.getOrDefault(0L)

            val versionName = runCatching {
                pkgInfo.versionName?.takeIf { it.isNotBlank() } ?: "1.0"
            }.getOrDefault("1.0")

            InstalledApp(
                name = appName,
                packageName = packageName,
                sizeBytes = sizeBytes,
                formattedSize = formatFileSize(sizeBytes),
                isSystemApp = isSystem,
                isGame = isGame,
                versionName = versionName
            )
        }.sortedWith(
            compareBy<InstalledApp> { it.isSystemApp }
                .thenBy { it.name.lowercase(Locale.getDefault()) }
        )
    }

    suspend fun getAppIcon(packageName: String): ImageBitmap? = withContext(Dispatchers.IO) {
        iconCache[packageName]?.let { return@withContext it }

        val imageBitmap = runCatching {
            val drawable = context.packageManager.getApplicationIcon(packageName)
            drawableToBitmap(drawable, maxSizePx = 96).asImageBitmap()
        }.getOrNull()

        if (imageBitmap != null) {
            iconCache[packageName] = imageBitmap
        }
        imageBitmap
    }

    private fun drawableToBitmap(drawable: Drawable, maxSizePx: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            val bmp = drawable.bitmap
            if (bmp.width <= maxSizePx && bmp.height <= maxSizePx) {
                return bmp
            }
            return Bitmap.createScaledBitmap(bmp, maxSizePx, maxSizePx, true)
        }
        val width = drawable.intrinsicWidth.takeIf { it > 0 }?.coerceAtMost(maxSizePx) ?: maxSizePx
        val height = drawable.intrinsicHeight.takeIf { it > 0 }?.coerceAtMost(maxSizePx) ?: maxSizePx
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "N/D"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
            else -> String.format(Locale.US, "%.0f KB", kb)
        }
    }
}
