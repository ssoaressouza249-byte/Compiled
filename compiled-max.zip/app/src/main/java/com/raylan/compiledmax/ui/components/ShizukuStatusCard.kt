package com.raylan.compiledmax.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.raylan.compiledmax.R
import com.raylan.compiledmax.model.ShizukuStatus
import com.raylan.compiledmax.ui.theme.CrimsonError
import com.raylan.compiledmax.ui.theme.GamerBg
import com.raylan.compiledmax.ui.theme.GamerCard
import com.raylan.compiledmax.ui.theme.GamerCardElevated
import com.raylan.compiledmax.ui.theme.NeonAmber
import com.raylan.compiledmax.ui.theme.NeonCyan
import com.raylan.compiledmax.ui.theme.NeonGreen
import com.raylan.compiledmax.ui.theme.TextSecondary

@Composable
fun ShizukuStatusCard(
    status: ShizukuStatus,
    shizukuInfo: String,
    onConnectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accentColor by animateColorAsState(
        targetValue = when (status) {
            ShizukuStatus.CONNECTED -> NeonGreen
            ShizukuStatus.AWAITING_PERMISSION -> NeonAmber
            ShizukuStatus.NOT_STARTED -> CrimsonError
        },
        label = "shizuku_accent"
    )

    val statusTitle = when (status) {
        ShizukuStatus.CONNECTED -> stringResource(R.string.shizuku_status_connected)
        ShizukuStatus.AWAITING_PERMISSION -> stringResource(R.string.shizuku_status_awaiting_permission)
        ShizukuStatus.NOT_STARTED -> stringResource(R.string.shizuku_status_not_started)
    }

    val statusDescription = when (status) {
        ShizukuStatus.CONNECTED -> stringResource(R.string.shizuku_desc_connected)
        ShizukuStatus.AWAITING_PERMISSION -> stringResource(R.string.shizuku_desc_awaiting_permission)
        ShizukuStatus.NOT_STARTED -> stringResource(R.string.shizuku_desc_not_started)
    }

    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        accentColor.copy(alpha = 0.55f),
                        GamerCardElevated
                    )
                ),
                shape = RoundedCornerShape(18.dp)
            )
            .testTag("shizuku_status_card"),
        shape = RoundedCornerShape(18.dp),
        color = GamerCard,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            accentColor.copy(alpha = 0.12f),
                            GamerCard.copy(alpha = 0.0f)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(accentColor.copy(alpha = 0.15f))
                            .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (status) {
                                ShizukuStatus.CONNECTED -> Icons.Filled.CheckCircle
                                ShizukuStatus.AWAITING_PERMISSION -> Icons.Filled.Shield
                                ShizukuStatus.NOT_STARTED -> Icons.Filled.PowerSettingsNew
                            },
                            contentDescription = statusTitle,
                            tint = accentColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .scale(if (status == ShizukuStatus.CONNECTED) pulseScale else 1f)
                                    .clip(CircleShape)
                                    .background(accentColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = statusTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (status == ShizukuStatus.CONNECTED) NeonGreen else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = shizukuInfo,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = accentColor.copy(alpha = 0.9f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = statusDescription,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            if (status != ShizukuStatus.CONNECTED) {
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = onConnectClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("shizuku_connect_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (status == ShizukuStatus.AWAITING_PERMISSION) NeonCyan else GamerCardElevated,
                        contentColor = if (status == ShizukuStatus.AWAITING_PERMISSION) GamerBg else NeonCyan
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.btn_connect_authorize_shizuku),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}
