package com.raylan.compiledmax

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.raylan.compiledmax.data.AppRepository
import com.raylan.compiledmax.security.SecurityGuardGate
import com.raylan.compiledmax.shizuku.ShizukuHelper
import com.raylan.compiledmax.ui.screens.AboutScreen
import com.raylan.compiledmax.ui.screens.MainScreen
import com.raylan.compiledmax.ui.theme.CompiledMaxTheme
import com.raylan.compiledmax.viewmodel.CompiledMaxViewModel

class MainActivity : ComponentActivity() {

    private lateinit var shizukuHelper: ShizukuHelper

    private val viewModel: CompiledMaxViewModel by viewModels {
        CompiledMaxViewModel.Factory(
            shizukuHelper = shizukuHelper,
            appRepository = AppRepository(applicationContext)
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        shizukuHelper = ShizukuHelper(applicationContext)
        shizukuHelper.registerLifecycleListeners()

        setContent {
            CompiledMaxTheme {
                SecurityGuardGate {
                    var showAboutScreen by rememberSaveable { mutableStateOf(false) }

                    if (showAboutScreen) {
                        AboutScreen(
                            onBack = { showAboutScreen = false }
                        )
                    } else {
                        MainScreen(
                            viewModel = viewModel,
                            onNavigateToAbout = { showAboutScreen = true }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::shizukuHelper.isInitialized) {
            shizukuHelper.refreshStatus()
        }
    }

    override fun onDestroy() {
        if (::shizukuHelper.isInitialized) {
            shizukuHelper.unregisterLifecycleListeners()
        }
        super.onDestroy()
    }
}
