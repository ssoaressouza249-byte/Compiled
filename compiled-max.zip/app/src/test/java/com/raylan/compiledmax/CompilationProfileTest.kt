package com.raylan.compiledmax

import com.raylan.compiledmax.model.CompilationProfile
import org.junit.Assert.assertEquals
import org.junit.Test

class CompilationProfileTest {

    @Test
    fun speedProfile_buildsExpectedCommand() {
        assertEquals(
            "cmd package compile -m speed -f com.raylan.samplegame",
            CompilationProfile.SPEED.buildCommand("com.raylan.samplegame")
        )
    }

    @Test
    fun everythingProfile_buildsExpectedCommand() {
        assertEquals(
            "cmd package compile -m everything -f com.raylan.samplegame",
            CompilationProfile.EVERYTHING.buildCommand("com.raylan.samplegame")
        )
    }

    @Test
    fun spaceProfile_buildsExpectedCommand() {
        assertEquals(
            "cmd package compile -m space-profile -f com.raylan.samplegame",
            CompilationProfile.SPACE.buildCommand("com.raylan.samplegame")
        )
    }

    @Test
    fun resetProfile_buildsExpectedCommand() {
        assertEquals(
            "cmd package compile --reset com.raylan.samplegame",
            CompilationProfile.RESET.buildCommand("com.raylan.samplegame")
        )
    }
}
