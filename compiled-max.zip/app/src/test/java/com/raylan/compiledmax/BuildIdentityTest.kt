package com.raylan.compiledmax

import org.junit.Assert.assertEquals
import org.junit.Test

class BuildIdentityTest {

    @Test
    fun applicationId_matchesOfficialPackage() {
        assertEquals("com.raylan.compiledmax", BuildConfig.APPLICATION_ID)
    }
}
